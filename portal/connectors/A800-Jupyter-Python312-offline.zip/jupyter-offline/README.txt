A800 Jupyter 离线依赖包

适用环境为当前 A800 的 Linux x86_64、Python 3.12。包含固定版本的
Jupyter Server 2.14.1、ipykernel 6.29.5，以及在 Linux Python 3.12
环境标记下所需的全部依赖。每个 wheel 均与官方 PyPI 发布文件的
SHA-256 核对。manifest.json 记录来源、版本和校验值。

将整个 A800-Jupyter-Python312-offline.zip 通过算力工作台上传至
/mnt/data，再在当前 A800 的网页终端运行以下两行。

python3 -m zipfile -e /mnt/data/A800-Jupyter-Python312-offline.zip /home/work/.compute-connect/jupyter/offline
python3 /home/work/.compute-connect/jupyter/offline/jupyter-offline/install.py

看到 WORKBENCH_JUPYTER_DEPENDENCIES_READY 表示依赖安装成功。
随后返回本机算力工作台，点击“连接远程 Jupyter 内核”，重新复制并
运行准备命令。看到 WORKBENCH_JUPYTER_READY 后再连接 Notebook。

安装器仅在 /home/work/.compute-connect/jupyter/venv 中安装依赖。
该环境保留访问实例原 Python 环境的包路径，方便使用已有 GPU 库。
安装时使用本包的完整锁定清单和哈希校验，不访问远程包仓库。
上传到子目录时，请相应调整第一行中的压缩包路径。

本包已完成依赖闭包、平台 wheel 和官方哈希校验。当前 Windows
环境无法执行 Linux wheel；最终导入和运行以 A800 上的安装结果为准。
