#!/usr/bin/env python3
"""Install the verified A800 Jupyter bundle in its private Python environment."""

import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import stat
import subprocess
import sys
import venv


def private_directory(path):
    path.mkdir(mode=0o700, exist_ok=True)
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        info = os.fstat(descriptor)
        if info.st_uid != os.geteuid() or info.st_mode & 0o022:
            raise RuntimeError(f'Unsafe private directory: {path}')
        if info.st_mode & 0o077:
            os.fchmod(descriptor, 0o700)
    finally:
        os.close(descriptor)


def verify_bundle(root):
    with (root / 'manifest.json').open(encoding='utf-8') as stream:
        manifest = json.load(stream)
    requirements = []
    for item in manifest['files']:
        name, version, filename, digest = (item[key] for key in ('name', 'version', 'filename', 'sha256'))
        if not re.fullmatch(r'[a-z0-9][a-z0-9-]*', name) or not re.fullmatch(r'[a-zA-Z0-9.+!_-]+', version):
            raise RuntimeError('Invalid package metadata')
        if Path(filename).name != filename or not filename.endswith('.whl') or not re.fullmatch(r'[a-f0-9]{64}', digest):
            raise RuntimeError('Invalid wheel metadata')
        wheel = root / 'wheels' / filename
        if wheel.is_symlink() or not wheel.is_file() or hashlib.sha256(wheel.read_bytes()).hexdigest() != digest:
            raise RuntimeError(f'Wheel verification failed: {filename}')
        requirements.append(f'{name}=={version} --hash=sha256:{digest}')
    expected = '\n'.join(requirements) + '\n'
    if (root / 'requirements.lock').read_text(encoding='utf-8') != expected:
        raise RuntimeError('Requirements do not match the verified manifest')


def main():
    if sys.platform != 'linux' or sys.version_info[:2] != (3, 12) or platform.machine() != 'x86_64':
        raise RuntimeError('This bundle requires the A800 Linux x86_64 / Python 3.12 environment.')
    root = Path(__file__).resolve().parent
    verify_bundle(root)
    os.umask(0o077)
    work = Path('/home/work')
    if not work.is_dir():
        raise RuntimeError('Run this installer inside the current A800 work environment.')
    parent = work / '.compute-connect'
    runtime = parent / 'jupyter'
    for directory in (parent, runtime):
        private_directory(directory)
    descriptor = os.open(runtime / 'setup.lock', os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
    with os.fdopen(descriptor, 'rb') as lock:
        info = os.fstat(lock.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o077:
            raise RuntimeError('Unsafe Jupyter installation lock')
        fcntl.flock(lock, fcntl.LOCK_EX)
        environment = runtime / 'venv'
        if environment.is_symlink():
            raise RuntimeError('The Jupyter virtual environment must be a regular directory')
        private_directory(environment)
        print('已校验离线依赖，正在准备 A800 的专用 Python 环境。', flush=True)
        venv.EnvBuilder(system_site_packages=True, with_pip=True).create(environment)
        python = environment / 'bin' / 'python'
        pip_environment = os.environ.copy()
        pip_environment['PIP_CONFIG_FILE'] = os.devnull
        command = [str(python), '-m', 'pip', '--isolated', '--disable-pip-version-check',
                   'install', '--no-index', '--no-deps', '--ignore-installed',
                   '--only-binary=:all:', '--require-hashes', '--find-links', str(root / 'wheels'),
                   '-r', str(root / 'requirements.lock')]
        subprocess.run(command, check=True, env=pip_environment, cwd=runtime)
        subprocess.run([str(python), '-c',
                        'import jupyter_server, ipykernel; '
                        'assert jupyter_server.__version__ == "2.14.1"; '
                        'assert ipykernel.__version__ == "6.29.5"; '
                        'print("WORKBENCH_JUPYTER_DEPENDENCIES_READY")'], check=True, cwd=runtime)
    print('安装完成。返回本机算力工作台，重新复制并运行 Jupyter 准备命令。', flush=True)


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, RuntimeError, subprocess.SubprocessError) as error:
        raise SystemExit(f'离线安装未完成：{error}') from None
